# Пример: Добавление настроек Git

Этот пример показывает, как расширить систему конфигурации для управления настройками Git.

## 1. Добавьте опции в modules/variables.nix

```nix
# В options.myConfig добавьте:
git = {
  enable = lib.mkOption {
    type = lib.types.bool;
    default = true;
    description = "Включить настройки Git";
  };
  
  userName = lib.mkOption {
    type = lib.types.str;
    default = config.myConfig.user.fullName;
    description = "Имя для коммитов Git";
  };
  
  userEmail = lib.mkOption {
    type = lib.types.str;
    default = config.myConfig.user.email;
    description = "Email для коммитов Git";
  };
  
  defaultBranch = lib.mkOption {
    type = lib.types.str;
    default = "main";
    description = "Имя ветки по умолчанию";
  };
  
  aliases = lib.mkOption {
    type = lib.types.attrsOf lib.types.str;
    default = {
      st = "status";
      co = "checkout";
      br = "branch";
      ci = "commit";
      lg = "log --oneline --graph --decorate";
    };
    description = "Алиасы для команд Git";
  };
};
```

## 2. Установите значения в flake.nix

```nix
myConfig = {
  # ... остальные настройки ...
  
  git = {
    enable = true;
    userName = "Your Full Name";  # Или оставьте пустым, чтобы использовалось user.fullName
    userEmail = "your@email.com"; # Или оставьте пустым, чтобы использовалось user.email
    defaultBranch = "main";
    aliases = {
      st = "status -sb";
      co = "checkout";
      br = "branch -v";
      ci = "commit";
      ca = "commit --amend";
      lg = "log --graph --pretty=format:'%Cred%h%Creset -%C(yellow)%d%Creset %s %Cgreen(%cr) %C(bold blue)<%an>%Creset'";
      last = "log -1 HEAD";
      unstage = "reset HEAD --";
      undo = "reset --soft HEAD^";
    };
  };
};
```

## 3. Создайте модуль для Git (необязательно)

Создайте файл `home/software/git.nix`:

```nix
{ config, lib, pkgs, ... }:

{
  programs.git = lib.mkIf config.myConfig.git.enable {
    enable = true;
    userName = config.myConfig.git.userName;
    userEmail = config.myConfig.git.userEmail;
    
    extraConfig = {
      init.defaultBranch = config.myConfig.git.defaultBranch;
      pull.rebase = true;
      push.autoSetupRemote = true;
      core.editor = config.myConfig.programs.editor;
    };
    
    aliases = config.myConfig.git.aliases;
    
    delta = {
      enable = true;
      options = {
        navigate = true;
        line-numbers = true;
        syntax-theme = "Dracula";
      };
    };
  };
}
```

## 4. Импортируйте модуль

В `home/core/home.nix`:

```nix
{ config, pkgs, ... }:
{
  imports = [
    ../software/packages.nix
    ../software/programs.nix
    ../software/git.nix        # Добавьте эту строку
  ];

  home.stateVersion = config.myConfig.system.stateVersion;
}
```

## Результат

Теперь у вас есть централизованное управление Git! Все изменения в одном месте:

```nix
# flake.nix
myConfig.git = {
  userName = "Ivan Petrov";      # Меняем имя
  userEmail = "ivan@example.ru"; # Меняем email
  defaultBranch = "master";      # Или "main"
  aliases.st = "status -sb";     # Кастомизируем алиасы
};
```

После `sudo nixos-rebuild switch --flake .#vortex` все изменения применятся автоматически!

## Аналогично можно добавить:

- **SSH**: ключи, алиасы хостов
- **Zsh/Bash**: плагины, алиасы, переменные окружения
- **Vim/Neovim**: плагины, настройки
- **Темы**: цветовые схемы для всей системы
- **Разработка**: версии Node.js, Python, Go и т.д.
