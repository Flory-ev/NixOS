{ lib, ... }:

{
  options.myConfig = {
    user = {
      name = lib.mkOption {
        type = lib.types.str;
        default = "user";
        description = "Имя пользователя системы";
        example = "john";
      };
      
      fullName = lib.mkOption {
        type = lib.types.str;
        default = "User Name";
        description = "Полное имя пользователя";
        example = "John Doe";
      };
      
      email = lib.mkOption {
        type = lib.types.str;
        default = "user@example.com";
        description = "Email пользователя";
        example = "john@example.com";
      };
      
      shell = lib.mkOption {
        type = lib.types.str;
        default = "zsh";
        description = "Командная оболочка пользователя";
        example = "bash";
      };
    };
    
    system = {
      hostname = lib.mkOption {
        type = lib.types.str;
        default = "nixos";
        description = "Имя хоста";
        example = "my-laptop";
      };
      
      timezone = lib.mkOption {
        type = lib.types.str;
        default = "UTC";
        example = "Europe/Copenhagen";
        description = "Временная зона системы";
      };
      
      locale = lib.mkOption {
        type = lib.types.str;
        default = "en_US.UTF-8";
        description = "Локаль системы";
      };
      
      stateVersion = lib.mkOption {
        type = lib.types.str;
        default = "25.05";
        description = "Версия состояния NixOS (не менять после установки)";
      };
    };
    
    keyboard = {
      layout = lib.mkOption {
        type = lib.types.str;
        default = "us";
        example = "us,ru";
        description = "Раскладка клавиатуры (можно указать несколько через запятую)";
      };
      
      variant = lib.mkOption {
        type = lib.types.str;
        default = "";
        example = "dvorak";
        description = "Вариант раскладки клавиатуры";
      };
      
      options = lib.mkOption {
        type = lib.types.str;
        default = "";
        example = "grp:alt_shift_toggle";
        description = "Опции клавиатуры (например, для переключения раскладок)";
      };
    };
    
    programs = {
      editor = lib.mkOption {
        type = lib.types.str;
        default = "vim";
        description = "Текстовый редактор по умолчанию";
        example = "nvim";
      };
    };
    
    laptop = {
      enable = lib.mkOption {
        type = lib.types.bool;
        default = false;
        description = "Включить настройки для ноутбука (управление питанием, touchpad и т.д.)";
      };
      
      touchpad = {
        naturalScrolling = lib.mkOption {
          type = lib.types.bool;
          default = true;
          description = "Включить естественную прокрутку на touchpad";
        };
        
        tapping = lib.mkOption {
          type = lib.types.bool;
          default = true;
          description = "Включить тап для клика на touchpad";
        };
        
        disableWhileTyping = lib.mkOption {
          type = lib.types.bool;
          default = false;
          description = "Отключать touchpad во время набора текста";
        };
        
        accelSpeed = lib.mkOption {
          type = lib.types.str;
          default = "0.5";
          description = "Скорость ускорения курсора на touchpad";
        };
      };
      
      battery = {
        startChargeThreshold = lib.mkOption {
          type = lib.types.int;
          default = 20;
          description = "Процент заряда, при котором начинается зарядка";
        };
        
        stopChargeThreshold = lib.mkOption {
          type = lib.types.int;
          default = 80;
          description = "Процент заряда, при котором останавливается зарядка";
        };
      };
    };
  };
}
