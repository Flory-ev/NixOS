# Централизованная конфигурация через модуль опций

## Что изменилось

Теперь все основные настройки системы управляются через модуль `modules/variables.nix`, который определяет опции с валидацией типов, документацией и значениями по умолчанию.

## Структура

```
modules/
  └── variables.nix          # Определение всех опций конфигурации

flake.nix                    # Установка значений для всех опций
```

## Как использовать

### 1. Изменить основные настройки

Откройте `flake.nix` и измените значения в блоке `myConfig`:

```nix
myConfig = {
  user = {
    name = "f";              # Имя пользователя
    fullName = "Your Name";  # Полное имя
    email = "you@email.com"; # Email
    shell = "zsh";           # Оболочка (zsh, bash, fish)
  };
  
  system = {
    hostname = "vortex";              # Имя хоста
    timezone = "Europe/Copenhagen";   # Временная зона
    locale = "en_US.UTF-8";          # Локаль
    stateVersion = "25.05";          # Версия (не менять!)
  };
  
  keyboard = {
    layout = "us,ru";                # Раскладки
    variant = "dvorak";              # Вариант раскладки
    options = "grp:alt_shift_toggle"; # Переключение раскладок
  };
  
  programs = {
    editor = "nvim";  # Редактор по умолчанию
  };
  
  laptop = {
    enable = true;    # Включить настройки ноутбука
    touchpad = {
      naturalScrolling = true;      # Естественная прокрутка
      tapping = true;               # Тап для клика
      disableWhileTyping = false;   # Отключать при наборе
      accelSpeed = "0.5";           # Скорость курсора
    };
    battery = {
      startChargeThreshold = 20;    # Начать заряжать при %
      stopChargeThreshold = 80;     # Остановить заряд при %
    };
  };
};
```

### 2. Применить изменения

После изменения `flake.nix`:

```bash
# Проверить конфигурацию
sudo nixos-rebuild dry-build --flake .#vortex

# Применить изменения
sudo nixos-rebuild switch --flake .#vortex
```

### 3. Добавить новые опции

Чтобы добавить новые опции, отредактируйте `modules/variables.nix`:

```nix
myNewOption = lib.mkOption {
  type = lib.types.str;      # Тип: str, int, bool, listOf, attrsOf и т.д.
  default = "defaultValue";  # Значение по умолчанию
  description = "Описание опции";
  example = "Пример значения";
};
```

Затем используйте в любом модуле:

```nix
{ config, ... }:
{
  some.setting = config.myConfig.myNewOption;
}
```

## Преимущества этого подхода

✅ **Валидация типов** - NixOS проверит правильность значений
✅ **Документация** - каждая опция имеет описание
✅ **Централизация** - все настройки в одном месте
✅ **Безопасность** - нельзя случайно использовать неправильный тип
✅ **Автодополнение** - редакторы с поддержкой Nix покажут доступные опции
✅ **Значения по умолчанию** - не нужно указывать всё вручную

## Примеры использования опций

### В любом модуле системы:

```nix
{ config, ... }:
{
  # Использовать имя пользователя
  services.someService.user = config.myConfig.user.name;
  
  # Использовать email
  programs.git.userEmail = config.myConfig.user.email;
  
  # Использовать настройки клавиатуры
  services.xserver.layout = config.myConfig.keyboard.layout;
  
  # Условная настройка на основе опции
  services.tlp.enable = config.myConfig.laptop.enable;
}
```

## Типы опций

Вот основные типы, которые можно использовать:

- `lib.types.str` - строка
- `lib.types.int` - целое число
- `lib.types.bool` - булево значение (true/false)
- `lib.types.listOf <type>` - список элементов типа
- `lib.types.attrsOf <type>` - атрибуты (словарь) с элементами типа
- `lib.types.enum [ "a" "b" "c" ]` - одно из перечисленных значений
- `lib.types.path` - путь к файлу/директории
- `lib.types.package` - пакет Nix

## Установка

### Заменить старые файлы на новые:

```bash
# Создать бэкап текущей конфигурации
cp -r ~/NixOS-Configuration-Main ~/NixOS-Configuration-Main.backup

# Заменить файлы (если вы в директории с конфигурацией)
mv flake.nix.new flake.nix
mv home/core/users.nix.new home/core/users.nix
mv home/core/home.nix.new home/core/home.nix
mv system/core/locale.nix.new system/core/locale.nix
mv system/core/settings.nix.new system/core/settings.nix
mv hosts/vortex/default.nix.new hosts/vortex/default.nix
mv profiles/laptop.nix.new profiles/laptop.nix

# Обновить flake
nix flake update

# Применить
sudo nixos-rebuild switch --flake .#vortex
```

## Добавление нового хоста

Чтобы добавить новый хост, например "desktop":

1. Создайте директорию `hosts/desktop/`
2. Добавьте в `flake.nix`:

```nix
nixosConfigurations = {
  vortex = nixpkgs.lib.nixosSystem { ... };
  
  desktop = nixpkgs.lib.nixosSystem {
    system = "x86_64-linux";
    specialArgs = { inherit inputs; };
    modules = [
      ./modules/variables.nix
      {
        myConfig = {
          user.name = "desktop-user";
          system.hostname = "desktop";
          laptop.enable = false;  # Это не ноутбук!
          # ... другие настройки ...
        };
      }
      ./hosts/desktop
      # ... остальное ...
    ];
  };
};
```

## Troubleshooting

### Ошибка "infinite recursion"
Убедитесь, что не используете `config.myConfig` в `modules/variables.nix` - там должны быть только определения опций.

### Ошибка "value is a <type> while a <other-type> was expected"
Проверьте, что тип значения в `flake.nix` соответствует типу в `modules/variables.nix`.

### Опция не применяется
Убедитесь, что модуль, использующий опцию, импортирован в вашем профиле или хосте.
