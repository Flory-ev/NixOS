#!/usr/bin/env bash

set -e

# Цвета для вывода
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${GREEN}=== Установка централизованной конфигурации NixOS ===${NC}\n"

# Проверяем, что мы в правильной директории
if [ ! -f "flake.nix" ]; then
    echo -e "${RED}Ошибка: flake.nix не найден. Запустите скрипт из корня конфигурации.${NC}"
    exit 1
fi

# Создаем бэкап
echo -e "${YELLOW}Создаю бэкап текущей конфигурации...${NC}"
BACKUP_DIR="../NixOS-Configuration-Main.backup-$(date +%Y%m%d-%H%M%S)"
cp -r . "$BACKUP_DIR"
echo -e "${GREEN}✓ Бэкап создан: $BACKUP_DIR${NC}\n"

# Создаем директорию modules если её нет
if [ ! -d "modules" ]; then
    echo -e "${YELLOW}Создаю директорию modules...${NC}"
    mkdir -p modules
fi

# Заменяем файлы
echo -e "${YELLOW}Применяю новые файлы конфигурации...${NC}"

if [ -f "flake.nix.new" ]; then
    mv flake.nix.new flake.nix
    echo -e "${GREEN}✓ flake.nix обновлен${NC}"
fi

if [ -f "home/core/users.nix.new" ]; then
    mv home/core/users.nix.new home/core/users.nix
    echo -e "${GREEN}✓ home/core/users.nix обновлен${NC}"
fi

if [ -f "home/core/home.nix.new" ]; then
    mv home/core/home.nix.new home/core/home.nix
    echo -e "${GREEN}✓ home/core/home.nix обновлен${NC}"
fi

if [ -f "system/core/locale.nix.new" ]; then
    mv system/core/locale.nix.new system/core/locale.nix
    echo -e "${GREEN}✓ system/core/locale.nix обновлен${NC}"
fi

if [ -f "system/core/settings.nix.new" ]; then
    mv system/core/settings.nix.new system/core/settings.nix
    echo -e "${GREEN}✓ system/core/settings.nix обновлен${NC}"
fi

if [ -f "hosts/vortex/default.nix.new" ]; then
    mv hosts/vortex/default.nix.new hosts/vortex/default.nix
    echo -e "${GREEN}✓ hosts/vortex/default.nix обновлен${NC}"
fi

if [ -f "profiles/laptop.nix.new" ]; then
    mv profiles/laptop.nix.new profiles/laptop.nix
    echo -e "${GREEN}✓ profiles/laptop.nix обновлен${NC}"
fi

echo ""

# Проверяем синтаксис
echo -e "${YELLOW}Проверяю синтаксис конфигурации...${NC}"
if nix flake check 2>/dev/null; then
    echo -e "${GREEN}✓ Синтаксис корректен${NC}\n"
else
    echo -e "${RED}✗ Обнаружены ошибки синтаксиса${NC}"
    echo -e "${YELLOW}Попробуйте: nix flake check${NC}\n"
fi

# Показываем следующие шаги
echo -e "${GREEN}=== Установка завершена! ===${NC}\n"
echo -e "${YELLOW}Следующие шаги:${NC}"
echo -e "1. Отредактируйте ${GREEN}flake.nix${NC} и установите свои значения в блоке ${GREEN}myConfig${NC}"
echo -e "2. Проверьте конфигурацию: ${GREEN}sudo nixos-rebuild dry-build --flake .#vortex${NC}"
echo -e "3. Примените изменения: ${GREEN}sudo nixos-rebuild switch --flake .#vortex${NC}"
echo -e "\n${YELLOW}Документация:${NC} см. ${GREEN}CONFIGURATION_GUIDE.md${NC}"
echo -e "${YELLOW}Бэкап:${NC} $BACKUP_DIR\n"
