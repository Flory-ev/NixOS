# ⚡ Быстрая установка

## Что внутри?

Ваша конфигурация NixOS теперь с централизованным управлением через модуль опций (вариант 3).

## Файлы

- `modules/variables.nix` - Определения всех опций (типы, описания, значения по умолчанию)
- `flake.nix.new` - Новый flake.nix с установкой значений
- `*.nix.new` - Обновленные модули, использующие `config.myConfig`
- `install-config.sh` - Скрипт автоматической установки
- `CONFIGURATION_GUIDE.md` - Полная документация
- `CHEATSHEET.md` - Шпаргалка для быстрого доступа
- `EXAMPLES_GIT.md` - Пример расширения системы (настройки Git)

## Установка

### Автоматически (рекомендуется)

```bash
# 1. Распакуйте архив
unzip NixOS-Configuration-Updated.zip
cd NixOS-Configuration-Main

# 2. Запустите скрипт установки
chmod +x install-config.sh
./install-config.sh
```

### Вручную

```bash
# 1. Создайте бэкап
cp -r ~/your-config ~/your-config.backup

# 2. Замените файлы
mv flake.nix.new flake.nix
mv home/core/users.nix.new home/core/users.nix
mv home/core/home.nix.new home/core/home.nix
mv system/core/locale.nix.new system/core/locale.nix
mv system/core/settings.nix.new system/core/settings.nix
mv hosts/vortex/default.nix.new hosts/vortex/default.nix
mv profiles/laptop.nix.new profiles/laptop.nix
```

## Настройка

### 1. Откройте flake.nix

Найдите блок `myConfig` и установите свои значения:

```nix
myConfig = {
  user = {
    name = "f";              # ← Ваше имя пользователя
    fullName = "Your Name";  # ← Ваше полное имя
    email = "you@email.com"; # ← Ваш email
    shell = "zsh";
  };
  
  system = {
    hostname = "vortex";              # ← Имя компьютера
    timezone = "Europe/Copenhagen";   # ← Ваш часовой пояс
    locale = "en_US.UTF-8";
    stateVersion = "25.05";           # ⚠️ НЕ МЕНЯЙТЕ!
  };
  
  # ... остальное ...
};
```

### 2. Примените конфигурацию

```bash
# Проверка
sudo nixos-rebuild dry-build --flake .#vortex

# Применение
sudo nixos-rebuild switch --flake .#vortex
```

## Что дальше?

- 📖 Читайте `CONFIGURATION_GUIDE.md` для полного понимания
- 📋 Используйте `CHEATSHEET.md` как шпаргалку
- 🎓 Смотрите `EXAMPLES_GIT.md` для примеров расширения

## Преимущества

✅ Все настройки в одном месте (flake.nix)
✅ Валидация типов (нельзя ошибиться с типом данных)
✅ Документация каждой опции
✅ Легко добавлять новые настройки
✅ Безопасно масштабируется на несколько хостов

## Поддержка

Если что-то пошло не так:
1. Восстановите из бэкапа
2. Проверьте синтаксис: `nix flake check`
3. Читайте секцию "Troubleshooting" в `CONFIGURATION_GUIDE.md`

---

Удачи! 🚀
