# Шпаргалка: Централизованная конфигурация NixOS

## 🎯 Быстрый старт

### Где менять настройки?
**Файл:** `flake.nix` → блок `myConfig`

### Основные настройки

```nix
myConfig = {
  user.name = "f";                    # Имя пользователя
  user.email = "you@email.com";       # Email
  system.hostname = "vortex";         # Имя компьютера
  system.timezone = "Europe/Copenhagen";  # Часовой пояс
  keyboard.layout = "us,ru";          # Раскладки клавиатуры
};
```

### Применить изменения

```bash
# Проверить перед применением
sudo nixos-rebuild dry-build --flake .#vortex

# Применить
sudo nixos-rebuild switch --flake .#vortex
```

## 📋 Полный список опций

### user (Пользователь)
- `name` - имя пользователя (string)
- `fullName` - полное имя (string)
- `email` - email адрес (string)
- `shell` - оболочка: "zsh", "bash", "fish" (string)

### system (Система)
- `hostname` - имя хоста (string)
- `timezone` - часовой пояс, например "Europe/Moscow" (string)
- `locale` - локаль, например "ru_RU.UTF-8" (string)
- `stateVersion` - версия системы ⚠️ НЕ МЕНЯТЬ после установки! (string)

### keyboard (Клавиатура)
- `layout` - раскладки через запятую, например "us,ru" (string)
- `variant` - вариант раскладки, например "dvorak" (string)
- `options` - опции, например "grp:alt_shift_toggle" (string)

### programs (Программы)
- `editor` - редактор по умолчанию: "vim", "nvim", "nano" (string)

### laptop (Ноутбук)
- `enable` - включить настройки ноутбука (boolean)

#### laptop.touchpad (Тачпад)
- `naturalScrolling` - естественная прокрутка (boolean)
- `tapping` - тап для клика (boolean)
- `disableWhileTyping` - отключать при печати (boolean)
- `accelSpeed` - скорость курсора "0.0" до "1.0" (string)

#### laptop.battery (Батарея)
- `startChargeThreshold` - начать заряд при % (integer, 0-100)
- `stopChargeThreshold` - остановить заряд при % (integer, 0-100)

## 🔧 Примеры конфигураций

### Для русскоязычного пользователя

```nix
myConfig = {
  user = {
    name = "ivan";
    fullName = "Иван Иванов";
    email = "ivan@example.ru";
    shell = "zsh";
  };
  system = {
    hostname = "laptop";
    timezone = "Europe/Moscow";
    locale = "ru_RU.UTF-8";
    stateVersion = "25.05";
  };
  keyboard = {
    layout = "us,ru";
    variant = "";
    options = "grp:alt_shift_toggle,grp_led:scroll";
  };
  laptop.enable = true;
};
```

### Для настольного ПК (не ноутбук)

```nix
myConfig = {
  user.name = "john";
  system.hostname = "desktop";
  laptop.enable = false;  # Отключаем настройки ноутбука!
};
```

### Продвинутые настройки тачпада

```nix
myConfig.laptop = {
  enable = true;
  touchpad = {
    naturalScrolling = true;    # Прокрутка как на Mac
    tapping = true;             # Тап = клик
    disableWhileTyping = true;  # Отключать при наборе
    accelSpeed = "0.7";         # Быстрый курсор
  };
  battery = {
    startChargeThreshold = 40;  # Заряжать с 40%
    stopChargeThreshold = 80;   # До 80% (продлевает жизнь батареи)
  };
};
```

## 💡 Полезные команды

```bash
# Показать текущую конфигурацию
nix eval .#nixosConfigurations.vortex.config.myConfig

# Проверить синтаксис
nix flake check

# Обновить зависимости
nix flake update

# Откатиться на предыдущую конфигурацию
sudo nixos-rebuild switch --rollback

# Посмотреть список поколений
sudo nix-env --list-generations --profile /nix/var/nix/profiles/system

# Удалить старые поколения (старше 7 дней)
sudo nix-collect-garbage --delete-older-than 7d
```

## 🆘 Частые проблемы

### Ошибка типа "expected string but got integer"
**Решение:** Проверьте тип значения. Числа пишите без кавычек, строки - в кавычках.
```nix
battery.startChargeThreshold = 20;    # ✓ Число без кавычек
system.hostname = "vortex";           # ✓ Строка в кавычках
```

### Не работает переключение раскладок
**Решение:** Проверьте `keyboard.options`:
```nix
keyboard.options = "grp:alt_shift_toggle";  # Alt+Shift для переключения
# Или
keyboard.options = "grp:caps_toggle";       # CapsLock для переключения
```

### Забыл что изменил
**Решение:** Сравните с бэкапом:
```bash
diff flake.nix ~/NixOS-Configuration-Main.backup-*/flake.nix
```

## 📂 Структура файлов

```
.
├── flake.nix                    ← ЗДЕСЬ менять настройки!
├── modules/
│   └── variables.nix            ← Определения опций (не трогать)
├── hosts/vortex/
│   └── default.nix              ← Использует myConfig
├── system/core/
│   ├── locale.nix               ← Использует myConfig
│   └── settings.nix             ← Использует myConfig
├── home/core/
│   ├── users.nix                ← Использует myConfig
│   └── home.nix                 ← Использует myConfig
└── profiles/
    └── laptop.nix               ← Использует myConfig
```

## 🎓 Добавление новых опций

В файле `modules/variables.nix`:

```nix
options.myConfig = {
  myNewSection = {
    myOption = lib.mkOption {
      type = lib.types.str;           # Тип данных
      default = "default value";      # Значение по умолчанию
      description = "Что это делает"; # Описание
      example = "example value";      # Пример
    };
  };
};
```

Использование в любом модуле:

```nix
{ config, ... }:
{
  some.setting = config.myConfig.myNewSection.myOption;
}
```

---

💾 **Не забывайте делать бэкапы перед большими изменениями!**
📖 **Полная документация:** `CONFIGURATION_GUIDE.md`
