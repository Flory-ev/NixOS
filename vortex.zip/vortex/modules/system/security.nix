{ ... }:

{
  security.sudo.wheelNeedsPassword = true;
}
